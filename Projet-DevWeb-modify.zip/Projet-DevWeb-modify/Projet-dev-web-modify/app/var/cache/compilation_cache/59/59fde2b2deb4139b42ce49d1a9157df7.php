<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_e4ccdb26ba60eb23940543c18b185a2a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Accueil - Entreprise Électrique</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        input[type=\"text\"],
        input[type=\"password\"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class=\"container\">
        <h1>Inscription</h1>
        <form>
            <label for=\"email\">Email d'utilisateur</label>
            <input type=\"text\" id=\"email\" name=\"email\" required>

            <h1>Inscription</h1>
        <form>
            <label for=\"email\">Email d'utilisateur</label>
            <input type=\"text\" id=\"email\" name=\"email\" required>

            <label for=\"password\">Mot de passe</label>
            <input type=\"password\" id=\"password\" name=\"password\" required>

            <label for=\"lastName\">Nom</label>
            <input type=\"text\" id=\"lastName\" name=\"lastName\" required>

            <label for=\"firstName\">Prénom</label>
            <input type=\"text\" id=\"firstName\" name=\"firstName\" required>

            <label for=\"country\">Pays</label>
            <input type=\"text\" id=\"country\" name=\"country\" required>

            <label for=\"city\">Ville</label>
            <input type=\"text\" id=\"city\" name=\"city\" required>

            <label for=\"phonenumber\">Numéro de téléphone</label>
            <input type=\"text\" id=\"phonenumber\" name=\"phonenumber\" required>

            <label for=\"status\">Statut</label>
            <select id=\"status\" name=\"status\" required>
                <option value=\"client\">Client</option>
                <option value=\"standardiste\">Standardiste</option>
                <option value=\"admin\">Administrateur</option>
                <option value=\"intervenant\">Intervenant</option>
            </select>

            <button type=\"submit\">Inscription</button>
        </form>
        <p>Déjà un compte ? <a href=\"register.html.twig\">Connectez-vous ici</a></p>
    </div>

</body>
</html>
";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "base.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Accueil - Entreprise Électrique</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        input[type=\"text\"],
        input[type=\"password\"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class=\"container\">
        <h1>Inscription</h1>
        <form>
            <label for=\"email\">Email d'utilisateur</label>
            <input type=\"text\" id=\"email\" name=\"email\" required>

            <h1>Inscription</h1>
        <form>
            <label for=\"email\">Email d'utilisateur</label>
            <input type=\"text\" id=\"email\" name=\"email\" required>

            <label for=\"password\">Mot de passe</label>
            <input type=\"password\" id=\"password\" name=\"password\" required>

            <label for=\"lastName\">Nom</label>
            <input type=\"text\" id=\"lastName\" name=\"lastName\" required>

            <label for=\"firstName\">Prénom</label>
            <input type=\"text\" id=\"firstName\" name=\"firstName\" required>

            <label for=\"country\">Pays</label>
            <input type=\"text\" id=\"country\" name=\"country\" required>

            <label for=\"city\">Ville</label>
            <input type=\"text\" id=\"city\" name=\"city\" required>

            <label for=\"phonenumber\">Numéro de téléphone</label>
            <input type=\"text\" id=\"phonenumber\" name=\"phonenumber\" required>

            <label for=\"status\">Statut</label>
            <select id=\"status\" name=\"status\" required>
                <option value=\"client\">Client</option>
                <option value=\"standardiste\">Standardiste</option>
                <option value=\"admin\">Administrateur</option>
                <option value=\"intervenant\">Intervenant</option>
            </select>

            <button type=\"submit\">Inscription</button>
        </form>
        <p>Déjà un compte ? <a href=\"register.html.twig\">Connectez-vous ici</a></p>
    </div>

</body>
</html>
", "base.html.twig", "/var/www/templates/base.html.twig");
    }
}
