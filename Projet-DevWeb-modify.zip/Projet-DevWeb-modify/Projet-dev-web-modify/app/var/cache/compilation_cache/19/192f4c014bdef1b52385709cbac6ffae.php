<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html.twig */
class __TwigTemplate_e4b1419f7f442d55e4cbd9990abc33c1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html>

<head>
    <style>
        /* ... (Styles inchangés) ... */

        /* Styles pour la page de connexion */


body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
  }
  
  .container {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  h1 {
    text-align: center;
    color: #333;
  }
  
  input[type=\"text\"],
  input[type=\"password\"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  
  button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: #ffffff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  button:hover {
    background-color: #0056b3;
  }
  
  /* Liens pour la récupération de mot de passe ou l'inscription */
  a {
    color: #007bff;
    text-decoration: none;
  }
  
  a:hover {
    text-decoration: underline;
  }
  
  .page-link {
    color: #007bff;
    text-decoration: none;
    /* On ajoutez d'autres styles si nécessaire */
  }
  
  .page-link:hover {
    text-decoration: underline;
    /* Styles pour le survol du lien */
  }
  
body {
  font-family: Arial, sans-serif;
  background-color: #f9f9f9;
}

.container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h1 {
  text-align: center;
  color: #333;
}

input[type=\"text\"],
input[type=\"password\"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: #ffffff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

/* Liens pour la récupération de mot de passe ou l'inscription */
a {
  color: #007bff;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

.page-link {
  color: #007bff;
  text-decoration: none;
  /* On ajoutez d'autres styles si nécessaire */
}

.page-link:hover {
  text-decoration: underline;
  /* Styles pour le survol du lien */
}

        
body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
  }
  
  .container {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  h1 {
    text-align: center;
    color: #333;
  }
  
  input[type=\"text\"],
  input[type=\"password\"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  
  button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: #ffffff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  button:hover {
    background-color: #0056b3;
  }
  
  /* Liens pour la récupération de mot de passe ou l'inscription */
  a {
    color: #007bff;
    text-decoration: none;
  }
  
  a:hover {
    text-decoration: underline;
  }
  
  .page-link {
    color: #007bff;
    text-decoration: none;
    /* On ajoutez d'autres styles si nécessaire */
  }
  
  .page-link:hover {
    text-decoration: underline;
    /* Styles pour le survol du lien */
  }
  
body {
  font-family: Arial, sans-serif;
  background-color: #f9f9f9;
}

.container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h1 {
  text-align: center;
  color: #333;
}

input[type=\"text\"],
input[type=\"password\"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: #ffffff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

/* Liens pour la récupération de mot de passe ou l'inscription */
a {
  color: #007bff;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

.page-link {
  color: #007bff;
  text-decoration: none;
  /* On ajoutez d'autres styles si nécessaire */
}

.page-link:hover {
  text-decoration: underline;
  /* Styles pour le survol du lien */
}


body {
            background-color: #fbd661;
            margin: 0; /* Remove default body margin */
            padding: 0; /* Remove default body padding */
        }

        h1 {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 15%;
            text-align: center;
            background-color: #05659fff;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            margin: 0; /* Remove default h1 margin */
        }

        .formulaire_inscription {
            position: fixed;
            top: 15%;
        }

        .Question-Box {
            display: flex;
            justify-content: flex-end;
            /* Align items to the right */
            align-items: center;
            background-color: grey;
            height: 20px;
            padding: 5%;
            font-family: 'Franklin Gothic Small', 'Arial Narrow', Arial, sans-serif;
            font-size: 100%;
            margin: 0; /* Remove default margin */
        }

        label {
            flex: 1;
        }

        input {
            margin-left: 10px;
        }

        .Validate {
            position: fixed;
            /* Position the button relative to the viewport */
            top: 50px;
            /* Position from the top edge of the viewport */
            right: 50%;
            /* Position from the right edge of the viewport */
            transform: translateX(50%);
            /* Center the button in the right half of the screen */
            text-align: center;
            margin: 0; /* Remove default margin */
        }

        input[type=\"submit\"] {
            padding: 10px 20px;
            font-size: 18px;
            background-color: #4CAF50;
            color: blue;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type=\"submit\"]:hover {
            background-color: #45a049;
            /* Darker green */
        }

        .button-container {
            position: fixed;
            top: 30%;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .button-container button {
            margin: 10px;
            padding: 10px 20px;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .button-container button:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>

    <div class=\"rounded-div\">
        .
    </div>

    <div class=\"button-container\">
        <!-- Formulaire de Connexion -->
        <form action=\"register.php\" method=\"post\">
            <button type=\"submit\">Connexion</button>
        </form>

        <!-- Formulaire d'Inscription -->
        <form action=\"connexion.html.twig\" method=\"post\">
            <button type=\"submit\">Inscription</button>
        </form>
    </div>

</body>

</html>
";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>

<head>
    <style>
        /* ... (Styles inchangés) ... */

        /* Styles pour la page de connexion */


body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
  }
  
  .container {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  h1 {
    text-align: center;
    color: #333;
  }
  
  input[type=\"text\"],
  input[type=\"password\"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  
  button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: #ffffff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  button:hover {
    background-color: #0056b3;
  }
  
  /* Liens pour la récupération de mot de passe ou l'inscription */
  a {
    color: #007bff;
    text-decoration: none;
  }
  
  a:hover {
    text-decoration: underline;
  }
  
  .page-link {
    color: #007bff;
    text-decoration: none;
    /* On ajoutez d'autres styles si nécessaire */
  }
  
  .page-link:hover {
    text-decoration: underline;
    /* Styles pour le survol du lien */
  }
  
body {
  font-family: Arial, sans-serif;
  background-color: #f9f9f9;
}

.container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h1 {
  text-align: center;
  color: #333;
}

input[type=\"text\"],
input[type=\"password\"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: #ffffff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

/* Liens pour la récupération de mot de passe ou l'inscription */
a {
  color: #007bff;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

.page-link {
  color: #007bff;
  text-decoration: none;
  /* On ajoutez d'autres styles si nécessaire */
}

.page-link:hover {
  text-decoration: underline;
  /* Styles pour le survol du lien */
}

        
body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
  }
  
  .container {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  h1 {
    text-align: center;
    color: #333;
  }
  
  input[type=\"text\"],
  input[type=\"password\"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  
  button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: #ffffff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  button:hover {
    background-color: #0056b3;
  }
  
  /* Liens pour la récupération de mot de passe ou l'inscription */
  a {
    color: #007bff;
    text-decoration: none;
  }
  
  a:hover {
    text-decoration: underline;
  }
  
  .page-link {
    color: #007bff;
    text-decoration: none;
    /* On ajoutez d'autres styles si nécessaire */
  }
  
  .page-link:hover {
    text-decoration: underline;
    /* Styles pour le survol du lien */
  }
  
body {
  font-family: Arial, sans-serif;
  background-color: #f9f9f9;
}

.container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h1 {
  text-align: center;
  color: #333;
}

input[type=\"text\"],
input[type=\"password\"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: #ffffff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

/* Liens pour la récupération de mot de passe ou l'inscription */
a {
  color: #007bff;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

.page-link {
  color: #007bff;
  text-decoration: none;
  /* On ajoutez d'autres styles si nécessaire */
}

.page-link:hover {
  text-decoration: underline;
  /* Styles pour le survol du lien */
}


body {
            background-color: #fbd661;
            margin: 0; /* Remove default body margin */
            padding: 0; /* Remove default body padding */
        }

        h1 {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 15%;
            text-align: center;
            background-color: #05659fff;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            margin: 0; /* Remove default h1 margin */
        }

        .formulaire_inscription {
            position: fixed;
            top: 15%;
        }

        .Question-Box {
            display: flex;
            justify-content: flex-end;
            /* Align items to the right */
            align-items: center;
            background-color: grey;
            height: 20px;
            padding: 5%;
            font-family: 'Franklin Gothic Small', 'Arial Narrow', Arial, sans-serif;
            font-size: 100%;
            margin: 0; /* Remove default margin */
        }

        label {
            flex: 1;
        }

        input {
            margin-left: 10px;
        }

        .Validate {
            position: fixed;
            /* Position the button relative to the viewport */
            top: 50px;
            /* Position from the top edge of the viewport */
            right: 50%;
            /* Position from the right edge of the viewport */
            transform: translateX(50%);
            /* Center the button in the right half of the screen */
            text-align: center;
            margin: 0; /* Remove default margin */
        }

        input[type=\"submit\"] {
            padding: 10px 20px;
            font-size: 18px;
            background-color: #4CAF50;
            color: blue;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type=\"submit\"]:hover {
            background-color: #45a049;
            /* Darker green */
        }

        .button-container {
            position: fixed;
            top: 30%;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .button-container button {
            margin: 10px;
            padding: 10px 20px;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .button-container button:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>

    <div class=\"rounded-div\">
        .
    </div>

    <div class=\"button-container\">
        <!-- Formulaire de Connexion -->
        <form action=\"register.php\" method=\"post\">
            <button type=\"submit\">Connexion</button>
        </form>

        <!-- Formulaire d'Inscription -->
        <form action=\"connexion.html.twig\" method=\"post\">
            <button type=\"submit\">Inscription</button>
        </form>
    </div>

</body>

</html>
", "index.html.twig", "/var/www/templates/index.html.twig");
    }
}
