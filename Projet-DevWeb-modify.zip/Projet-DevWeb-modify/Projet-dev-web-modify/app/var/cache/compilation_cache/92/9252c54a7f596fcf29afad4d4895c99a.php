<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* register.html.twig */
class __TwigTemplate_0f5d133dec4abe7522e07d7703b7a89e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Accueil - Entreprise Électrique</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        input[type=\"text\"],
        input[type=\"password\"],
        input[type=\"email\"],
        select,
        input[type=\"file\"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .login-container {
            display: none;
        }

        .login-container h1 {
            color: #555;
        }
    </style>
</head>
<body>

    <div class=\"container\" id=\"registration-container\">
        <h1>Inscription</h1>
        <form>
            <!-- Champs de formulaire pour l'inscription -->
            <label for=\"firstName\">Prénom</label>
            <input type=\"text\" id=\"firstName\" name=\"firstName\" required>

            <label for=\"lastName\">Nom</label>
            <input type=\"text\" id=\"lastName\" name=\"lastName\" required>

            <label for=\"status\">Statut</label>
            <select id=\"status\" name=\"status\" required>
                <option value=\"client\">Client</option>
                <option value=\"standardiste\">Standardiste</option>
                <option value=\"admin\">Administrateur</option>
                <option value=\"intervenant\">Intervenant</option>
            </select>

            <label for=\"address\">Adresse de domicile</label>
            <input type=\"text\" id=\"address\" name=\"address\" required>

            <label for=\"phonenumber\">Numéro de téléphone</label>
            <input type=\"text\" id=\"phonenumber\" name=\"phonenumber\" required>

            <label for=\"country\">Pays</label>
            <input type=\"text\" id=\"country\" name=\"country\" required>

            <label for=\"city\">Ville</label>
            <input type=\"text\" id=\"city\" name=\"city\" required>

            <button type=\"submit\" name=\"send\" value=\"Créer\">Inscription</button>
        </form>
        <p>Déjà un compte ? <a href=\"#\" onclick=\"showLogin()\">Connectez-vous ici</a></p>
    </div>

    <div class=\"container login-container\" id=\"login-container\">
        <h1>Connexion</h1>
        <form>
            <!-- Champs de formulaire pour la connexion -->
            <label for=\"email\">Entrez votre email</label>
            <input type=\"email\" required=\"required\" id=\"email\" name=\"email\" placeholder=\"Entrez votre email\">

            <label for=\"password\">Entrez votre mot de passe</label>
            <input type=\"password\" required=\"required\" id=\"password\" name=\"password\" placeholder=\"Entrez votre mot de passe\">

            <label for=\"statusLogin\">Statut</label>
            <select id=\"statusLogin\" name=\"statusLogin\" required>
                <option value=\"client\">Client</option>
                <option value=\"standardiste\">Standardiste</option>
                <option value=\"admin\">Administrateur</option>
                <option value=\"intervenant\">Intervenant</option>
            </select>

            <label for=\"profile_image\">Sélectionnez votre image de profil</label>
            <input type=\"file\" id=\"profile_image\" name=\"profile_image\" accept=\"image/*\">

            <button type=\"submit\">Connexion</button>
        </form>
        <p>Pas encore de compte ? <a href=\"#\" onclick=\"showRegistration()\">Inscrivez-vous ici</a></p>
    </div>

    <script>
        function showLogin() {
            document.getElementById('registration-container').style.display = 'none';
            document.getElementById('login-container').style.display = 'block';
        }

        function showRegistration() {
            document.getElementById('login-container').style.display = 'none';
            document.getElementById('registration-container').style.display = 'block';
        }
    </script>

</body>
</html>
";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "register.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Accueil - Entreprise Électrique</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        input[type=\"text\"],
        input[type=\"password\"],
        input[type=\"email\"],
        select,
        input[type=\"file\"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .login-container {
            display: none;
        }

        .login-container h1 {
            color: #555;
        }
    </style>
</head>
<body>

    <div class=\"container\" id=\"registration-container\">
        <h1>Inscription</h1>
        <form>
            <!-- Champs de formulaire pour l'inscription -->
            <label for=\"firstName\">Prénom</label>
            <input type=\"text\" id=\"firstName\" name=\"firstName\" required>

            <label for=\"lastName\">Nom</label>
            <input type=\"text\" id=\"lastName\" name=\"lastName\" required>

            <label for=\"status\">Statut</label>
            <select id=\"status\" name=\"status\" required>
                <option value=\"client\">Client</option>
                <option value=\"standardiste\">Standardiste</option>
                <option value=\"admin\">Administrateur</option>
                <option value=\"intervenant\">Intervenant</option>
            </select>

            <label for=\"address\">Adresse de domicile</label>
            <input type=\"text\" id=\"address\" name=\"address\" required>

            <label for=\"phonenumber\">Numéro de téléphone</label>
            <input type=\"text\" id=\"phonenumber\" name=\"phonenumber\" required>

            <label for=\"country\">Pays</label>
            <input type=\"text\" id=\"country\" name=\"country\" required>

            <label for=\"city\">Ville</label>
            <input type=\"text\" id=\"city\" name=\"city\" required>

            <button type=\"submit\" name=\"send\" value=\"Créer\">Inscription</button>
        </form>
        <p>Déjà un compte ? <a href=\"#\" onclick=\"showLogin()\">Connectez-vous ici</a></p>
    </div>

    <div class=\"container login-container\" id=\"login-container\">
        <h1>Connexion</h1>
        <form>
            <!-- Champs de formulaire pour la connexion -->
            <label for=\"email\">Entrez votre email</label>
            <input type=\"email\" required=\"required\" id=\"email\" name=\"email\" placeholder=\"Entrez votre email\">

            <label for=\"password\">Entrez votre mot de passe</label>
            <input type=\"password\" required=\"required\" id=\"password\" name=\"password\" placeholder=\"Entrez votre mot de passe\">

            <label for=\"statusLogin\">Statut</label>
            <select id=\"statusLogin\" name=\"statusLogin\" required>
                <option value=\"client\">Client</option>
                <option value=\"standardiste\">Standardiste</option>
                <option value=\"admin\">Administrateur</option>
                <option value=\"intervenant\">Intervenant</option>
            </select>

            <label for=\"profile_image\">Sélectionnez votre image de profil</label>
            <input type=\"file\" id=\"profile_image\" name=\"profile_image\" accept=\"image/*\">

            <button type=\"submit\">Connexion</button>
        </form>
        <p>Pas encore de compte ? <a href=\"#\" onclick=\"showRegistration()\">Inscrivez-vous ici</a></p>
    </div>

    <script>
        function showLogin() {
            document.getElementById('registration-container').style.display = 'none';
            document.getElementById('login-container').style.display = 'block';
        }

        function showRegistration() {
            document.getElementById('login-container').style.display = 'none';
            document.getElementById('registration-container').style.display = 'block';
        }
    </script>

</body>
</html>
", "register.html.twig", "/var/www/templates/register.html.twig");
    }
}
